-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: grocerydb
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `employee_id` int NOT NULL,
  `emp_firstName` varchar(55) NOT NULL,
  `emp_lastName` varchar(55) NOT NULL,
  `dept_id` int NOT NULL,
  `authority_level` int NOT NULL,
  `date_of_birth` date NOT NULL,
  `hire_date` date NOT NULL,
  `store_name` varchar(55) NOT NULL,
  `wage_rate` decimal(10,2) NOT NULL,
  PRIMARY KEY (`employee_id`),
  KEY `dept_id` (`dept_id`),
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (100,'Trevor','Potts',0,3,'1974-12-26','2007-07-03','Food World',35.00),(101,'Frank','Turner',4,3,'1970-02-28','1996-06-02','Food World',27.00),(102,'Ashley','Stewart',5,3,'1976-07-17','1996-10-15','Food World',28.00),(103,'Samuel','Godwin',3,3,'1989-01-27','2006-09-19','Food World',26.00),(104,'Paula','James',2,3,'1995-05-29','2013-05-14','Food World',25.00),(105,'Nancy','Matthews',1,3,'1982-11-07','1999-09-15','Food World',30.00),(111,'James','Connor',1,1,'2002-08-09','2020-02-23','Food World',15.00),(112,'Trevon','Stewart',1,3,'1986-12-19','2005-05-08','Food World',17.00),(113,'Michael','Scott',2,3,'1973-02-26','1990-06-17','Food World',17.25),(118,'Stephanie','Johnson',1,3,'1998-09-11','2012-09-11','Food World',16.00),(119,'Christopher','Qaqish',2,1,'2000-10-29','2021-12-07','Food World',15.00),(121,'Selena','Rivero',3,3,'1978-08-15','1992-09-10','Food World',21.75),(122,'Kyra','Martins',4,1,'2001-03-14','2019-05-18','Food World',15.25),(123,'Albert','Smith',5,1,'2002-06-21','2019-09-23','Food World',15.25),(124,'Julia','Roberts',2,1,'2000-07-07','2020-06-08','Food World',15.00);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-23 13:47:19
