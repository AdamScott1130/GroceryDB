-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: grocerydb
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `department` (
  `dept_name` varchar(255) NOT NULL,
  `dept_manager_id` int NOT NULL,
  `dept_id` int NOT NULL,
  PRIMARY KEY (`dept_id`),
  KEY `dept_manager_id` (`dept_manager_id`),
  CONSTRAINT `department_ibfk_1` FOREIGN KEY (`dept_manager_id`) REFERENCES `employee` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES ('Store Administration',100,0),('Front End',105,1),('Dry',104,2),('Bakery',103,3),('Meat',101,4),('Produce',102,5);
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `employee_id` int NOT NULL,
  `emp_firstName` varchar(55) NOT NULL,
  `emp_lastName` varchar(55) NOT NULL,
  `dept_id` int NOT NULL,
  `authority_level` int NOT NULL,
  `date_of_birth` date NOT NULL,
  `hire_date` date NOT NULL,
  `wage_rate` decimal(10,2) NOT NULL,
  PRIMARY KEY (`employee_id`),
  KEY `dept_id` (`dept_id`),
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (100,'Trevor','Potts',0,3,'1974-12-26','2007-07-03',35.00),(101,'Frank','Turner',4,3,'1970-02-28','1996-06-02',26.59),(102,'Ashley','Stewart',5,3,'1976-07-17','1996-10-15',28.00),(103,'Samuel','Godwin',3,3,'1989-01-27','2006-09-19',26.00),(104,'Paula','James',2,3,'1995-05-29','2013-05-14',25.00),(105,'Nancy','Matthews',1,3,'1982-11-07','1999-09-15',30.00),(111,'James','Connor',1,1,'2002-08-09','2020-02-23',15.00),(112,'Trevon','Stewart',1,3,'1986-12-19','2005-05-08',17.00),(113,'Michael','Scott',2,3,'1973-02-26','1990-06-17',17.25),(118,'Stephanie','Johnson',1,3,'1998-09-11','2012-09-11',16.00),(119,'Christopher','Qaqish',2,1,'2000-10-29','2021-12-07',15.00),(121,'Selena','Rivero',3,3,'1978-08-15','1992-09-10',21.75),(122,'Kyra','Martins',4,1,'2001-03-14','2019-05-18',15.25),(123,'Albert','Smith',5,1,'2002-06-21','2019-09-23',15.25),(124,'Julia','Roberts',2,1,'2000-07-07','2020-06-08',15.00);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_history`
--

DROP TABLE IF EXISTS `price_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price_history` (
  `UPC` varchar(12) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `price` decimal(6,2) NOT NULL,
  PRIMARY KEY (`UPC`,`start_date`),
  CONSTRAINT `price_history_ibfk_1` FOREIGN KEY (`UPC`) REFERENCES `product` (`UPC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_history`
--

LOCK TABLES `price_history` WRITE;
/*!40000 ALTER TABLE `price_history` DISABLE KEYS */;
INSERT INTO `price_history` VALUES ('212211242224','2017-03-15','2020-06-20',6.00),('212211242224','2020-06-21',NULL,6.75),('311331723228','2020-12-11','2021-04-03',7.34),('311331723228','2021-04-04',NULL,7.75),('615511243226','2018-08-23','2019-03-07',4.50),('615511243226','2019-03-08',NULL,4.75),('711111331223','2020-04-02','2020-05-01',5.00),('711111331223','2020-05-02',NULL,5.75),('811611226224','2018-05-06','2020-04-03',4.90),('811611226224','2020-04-04',NULL,5.25),('911211232222','2020-06-12','2021-03-15',5.63),('911211232222','2021-03-16',NULL,6.00);
/*!40000 ALTER TABLE `price_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `UPC` varchar(12) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `inv_count` int NOT NULL,
  `auth_level` int NOT NULL,
  `dept_id` int NOT NULL,
  PRIMARY KEY (`UPC`),
  UNIQUE KEY `UPC` (`UPC`),
  KEY `dept_id` (`dept_id`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES ('212211242224','cashier',202,1,2),('311331723228','fruit rack',133,1,5),('615511243226','bakery',0,1,3),('711111331223','shelf',24,3,2),('811611226224','freezer',10,1,2),('911211232222','meat fridge',12,1,4);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store` (
  `store_name` varchar(50) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `mgr_ID` int NOT NULL,
  PRIMARY KEY (`store_name`),
  UNIQUE KEY `store_name` (`store_name`),
  KEY `mgr_ID` (`mgr_ID`),
  CONSTRAINT `store_ibfk_1` FOREIGN KEY (`mgr_ID`) REFERENCES `employee` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
INSERT INTO `store` VALUES ('Food World','123 Database Street, Waterloo, Ontario',100);
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `happened_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total_cost` decimal(15,2) NOT NULL,
  `cashier_id` int NOT NULL,
  `till_number` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cashier_id` (`cashier_id`),
  CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`cashier_id`) REFERENCES `employee` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (1,'2022-03-23 22:32:34',13.00,105,5),(2,'2022-03-23 22:32:34',26.46,118,8);
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_line`
--

DROP TABLE IF EXISTS `transaction_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_line` (
  `UPC` varchar(12) NOT NULL,
  `Quantity` smallint unsigned DEFAULT NULL,
  `Weight` decimal(6,3) DEFAULT NULL,
  `Price_per_unit` decimal(6,2) NOT NULL,
  `Trans_ID` int NOT NULL,
  PRIMARY KEY (`Trans_ID`,`UPC`),
  KEY `UPC` (`UPC`),
  CONSTRAINT `transaction_line_ibfk_1` FOREIGN KEY (`UPC`) REFERENCES `product` (`UPC`),
  CONSTRAINT `transaction_line_ibfk_2` FOREIGN KEY (`Trans_ID`) REFERENCES `transaction` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_line`
--

LOCK TABLES `transaction_line` WRITE;
/*!40000 ALTER TABLE `transaction_line` DISABLE KEYS */;
INSERT INTO `transaction_line` VALUES ('311331723228',NULL,1.150,7.75,1),('711111331223',2,NULL,5.75,1),('811611226224',3,NULL,6.75,1);
/*!40000 ALTER TABLE `transaction_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'grocerydb'
--
/*!50003 DROP PROCEDURE IF EXISTS `deptRaise` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deptRaise`(dID INTEGER, raiseValue DECIMAL(3,2))
BEGIN
	SET SQL_SAFE_UPDATES = 0;
	UPDATE 	employee
    SET 	wage_rate = wage_rate * raiseValue
    WHERE 	dept_id = dID;
    SET SQL_SAFE_UPDATES = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `employeeRaise` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `employeeRaise`(eID Integer, raiseValue DECIMAL(3,2))
BEGIN
	UPDATE 	employee
    SET 	wage_rate = wage_rate * raiseValue
    WHERE 	employee_id = eID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getHistoricPrice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getHistoricPrice`(boughtOn date, barcode varchar(12))
BEGIN
		SELECT 	Price 
        FROM 	price_history
        WHERE	barcode = upc 
        AND 	boughtOn > start_date 
        AND 	boughtOn <= end_date;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getLines` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getLines`(x integer)
BEGIN
	SELECT * FROM transaction_line where Trans_ID = x;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `recieptInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `recieptInfo`(sName VARCHAR(50), tID INTEGER)
BEGIN
	SELECT store_name AS "Store Name",
	address AS "Address", 
    emp_firstName AS "Your Cashier Today",
	Cashier_id AS "Cashier ID", 
	Happened_at AS "Time of Transaction", 
	Till_number AS "Till Number", 
	id AS "Transaction ID", 
	mgr_ID AS "Store Manager", 
	total_cost AS "Total"
	FROM store, transaction, employee
	WHERE store_name = sName AND id = tID AND  employee_id = Cashier_ID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-30 23:30:56
