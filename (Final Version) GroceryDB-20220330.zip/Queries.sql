-- SQL File containing calls to useful stored procedures.

-- Given tranaction ID, select each transaction line associated with that transaction
Call getLines(1);

-- Given a date and a barcode, get the price of the product
-- associated with that barcode on the date provided
Call getHistoricPrice('2021-02-02', 911211232222);

-- Given an employee ID and the raise amount (1.xx) where xx is the % raise,
-- update that employee's wage_rate by the raise amount.
SELECT employee_id, emp_firstName, emp_lastName, wage_rate
FROM employee
WHERE employee_id = 101;

Call employeeRaise(101, 1.10);

SELECT employee_id, emp_firstName, emp_lastName , wage_rate
FROM employee
WHERE employee_id = 101;

-- Given a department ID and the raise value, give everyone in that department a raise
SELECT employee_id, emp_firstName, emp_lastName , wage_rate
FROM employee
WHERE dept_id = 2;

Call deptRaise(2, 1.05);

SELECT employee_id, emp_firstName, emp_lastName , wage_rate
FROM employee
WHERE dept_id = 2;

-- Given the store name and the transaction ID, return many attributes that would
-- appear on a reciept

call recieptInfo("Food World", 1);